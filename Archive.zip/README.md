# Refereme by TargetCatcher

An application that helps employee to provide refferall service to jobseeker

## Getting Started

To run the application, you can do the following:
```bash
flutter pub get
flutter run -d <device id>
```
