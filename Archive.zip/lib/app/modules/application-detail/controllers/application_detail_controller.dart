import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rating_dialog/rating_dialog.dart';
import 'package:referme/app/data/const.dart';
import 'package:referme/app/modules/home/controllers/notification_controller.dart';
import 'package:referme/app/routes/app_pages.dart';

class ApplicationDetailController extends GetxController {
  late final OrderData data;

  final _dialog = RatingDialog(
    initialRating: 4.0,
    // your app's name?
    title: const Text(
      'Rate current order',
      textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: 25,
        fontWeight: FontWeight.bold,
      ),
    ),
    enableComment: false,
    // encourage your user to leave a high rating?
    message: const Text(
      'Tap a star to set your rating',
      textAlign: TextAlign.center,
      style: TextStyle(fontSize: 15),
    ),
    // your app's logo?
    submitButtonText: 'Submit',
    onSubmitted: (response) {
      print('rating: ${response.rating}, comment: ${response.comment}');
    },
  );

  @override
  void onInit() {
    data = Get.arguments;
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void showCV() => Get.toNamed(Routes.CV_VIEWER,
      arguments: "${ConstData.serverUrl}/application/cv/${data.cvID}");
}
